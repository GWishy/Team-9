﻿using System;
using static System.Console;

namespace helloWorld
{
    public class CapstoneSprint4
    {
        public static void Main()
        {
            WriteLine("Hello World");
            WriteLine("Press Enter to Contiue.");
            Read();

        }




    }
}